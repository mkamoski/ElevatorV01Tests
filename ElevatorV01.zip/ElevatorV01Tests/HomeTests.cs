﻿// Filename: HomeTests.cs
using Bunit;
using ElevatorV01.Components.Pages;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace ElevatorV01.Tests
{
    [TestClass]
    public class HomeTests
    {
        public const int DefaultFloorMin = 1;
        public const int DefaultFloorMax = 5;

        [TestMethod]
        public void CallElevator_WhenCalledWithFloorOnly()
        {
            for (int myFloor = HomeTests.DefaultFloorMin; myFloor <= HomeTests.DefaultFloorMax; myFloor++)
            {
                // Arrange
                var expectedOutput = "Called elevator to floor " + myFloor;
                var consoleWriter = new StringWriter();
                Console.SetOut(consoleWriter);

                // Act
                using var ctx = new Bunit.TestContext();
                var cut = ctx.RenderComponent<Home>();
                string actualOutput = cut.Instance.CallElevator(myFloor);

                string myTest = consoleWriter.ToString().Trim();

                // Assert
                Assert.AreEqual(expectedOutput, actualOutput);
            }
        }

        [TestMethod]
        public void CallElevator_WhenCalledWithFloorAndDirection()
        {
            Home.Direction myDirection = Home.Direction.Down;

            for (int myFloor = HomeTests.DefaultFloorMin; myFloor <= HomeTests.DefaultFloorMax; myFloor++)
            {
                // Arrange
                var expectedOutput = "Called elevator to floor " + myFloor + " (" + myDirection.ToString() + ")";
                var consoleWriter = new StringWriter();
                Console.SetOut(consoleWriter);

                // Act
                using var ctx = new Bunit.TestContext();
                var cut = ctx.RenderComponent<Home>();
                string actualOutput = cut.Instance.CallElevator(myFloor, myDirection);

                string myTest = consoleWriter.ToString().Trim();

                // Assert
                Assert.AreEqual(expectedOutput, actualOutput);
            }

            myDirection = Home.Direction.Up;

            for (int myFloor = HomeTests.DefaultFloorMin; myFloor <= HomeTests.DefaultFloorMax; myFloor++)
            {
                // Arrange
                var expectedOutput = "Called elevator to floor " + myFloor + " (" + myDirection.ToString() + ")";
                var consoleWriter = new StringWriter();
                Console.SetOut(consoleWriter);

                // Act
                using var ctx = new Bunit.TestContext();
                var cut = ctx.RenderComponent<Home>();
                string actualOutput = cut.Instance.CallElevator(myFloor, myDirection);

                string myTest = consoleWriter.ToString().Trim();

                // Assert
                Assert.AreEqual(expectedOutput, actualOutput);
            }


        }


    }
}

